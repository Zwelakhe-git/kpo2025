function interviewsSection(interviewsData) {
    let interviewsList = '';
    for(let index = 0; index < interviewsData.interviews.length; ++index){
        let highlightsList = '';
        for(let j = 0; j < interviewsData.interviews[index].highlights.length; j++) {
            highlightsList += `<li>${interviewsData.interviews[index].highlights[j]}</li>`;
        }
        
        interviewsList += `
        <div class="interview-card">
            <div class="iv-container">
                <img src="${interviewsData.interviews[index].image_location}" alt="${interviewsData.interviews[index].personName}" class="interview-image" />
                <div class="interview-content">
                    <div class="person-info">
                        <h3 class="person-name">${interviewsData.interviews[index].personName}</h3>
                        <p class="person-title">${interviewsData.interviews[index].personTitle}</p>
                        <div class="interview-meta">
                            <span class="date">
                                <i class="fas fa-calendar"></i>
                                ${interviewsData.interviews[index].interviewDate}
                            </span>
                            <span class="read-time">
                                <i class="fas fa-clock"></i>
                                ${interviewsData.interviews[index].readTime}
                            </span>
                        </div>
                    </div>
                    <p class="interview-description">${interviewsData.interviews[index].description}</p>
                    <div class="interview-highlights">
                        <h4>Pwen Enpòtan:</h4>
                        <ul>${highlightsList}</ul>
                    </div>
                    <div class="interview-actions">
                        <a href="${interviewsData.interviews[index].videoUrl}" class="watch-btn">
                            <i class="fas fa-play"></i>
                            Gade Entèvyou
                        </a>
                        <button class="share-btn">
                            <i class="fas fa-share-alt"></i>
                            Pataje
                        </button>
                    </div>
                </div>
            </div>
        </div>`;
    }
    
    return `
    <div id="interviews-section" class="margin-rl-1 colDir container-outer pad-20 white-bg bdr-box">
        <div id="interviews-section-bg" class="full-h"></div>
        <div class="section-info">
            <h1>${interviewsData.pageTitle.toUpperCase()}</h1>
            <p>${interviewsData.pageDescription}</p>
        </div>
        <div id="interviews-list" class="container-inner">
            ${interviewsList}
        </div>
        <a href="/?p=more-interviews">
            <div class="more-actions">
                <span>Wè Plis Entèvyou</span>
                <ion-icon name="arrow-forward-outline"></ion-icon>
            </div>
        </a>
    </div>`;
}

export {interviewsSection};