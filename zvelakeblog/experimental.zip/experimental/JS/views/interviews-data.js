const interviewsData = {
    pageTitle: "Entèvyou",
    pageDescription: "Dekouvri tout entèvyou ak moun enpòtan yo",
    interviews: [
        {
            id: 1,
            personName: "Jean Pierre",
            personTitle: "CEO nan Biznis Enpòtan",
            interviewDate: "15 Janvye 2024",
            image_location: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
            description: "Nan entèvyou sa a, nou pale sou chaleng biznis nan Haiti, opòtinite ekonomik ak konsey pou jèn antreprenè yo.",
            highlights: [
                "Kijan li kòmanse biznis li a",
                "Chaleng li te fè fas",
                "Konsey pou jèn antreprenè"
            ],
            videoUrl: "#",
            readTime: "5 min"
        },
        {
            id: 2,
            personName: "Marie Claude",
            personTitle: "Atis ak Aktivist Kiltirèl",
            interviewDate: "8 Fevriye 2024",
            image_location: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
            description: "Marie Claude pataje wout li kòm atis fanm nan Haiti. Li eksplike kijan atizay ka sèvi kòm zouti pou chanje sosyete a.",
            highlights: [
                "Wòl atizay nan sosyete a",
                "Eksperyans kòm fanm atis",
                "Pwojè kominotè li yo"
            ],
            videoUrl: "#",
            readTime: "7 min"
        }
    ]
};

export {interviewsData}