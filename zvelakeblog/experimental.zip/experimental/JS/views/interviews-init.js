import {interviewsData} from './interviews-data.js';
import {interviewsSection} from './interviews-section.js';

function initInterviewsPage() {
    let root = document.querySelector("#root");
    if(!root){
        console.log("interviews: root element not found");
        return;
    }
    
    // Ajouter les styles si nécessaire
    if (!document.querySelector('#interviews-styles')) {
        const styleLink = document.createElement('link');
        styleLink.rel = 'stylesheet';
        styleLink.href = '/experimental/CSS/interviews-styles.css';
        styleLink.id = 'interviews-styles';
        document.head.appendChild(styleLink);
    }
    
    root.innerHTML = interviewsSection(interviewsData);
    
    // Ajouter les event listeners
    setTimeout(() => {
        const shareButtons = document.querySelectorAll('.share-btn');
        shareButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Fonctionnalité de partage
                if (navigator.share) {
                    navigator.share({
                        title: 'Entèvyou - Konektem',
                        text: 'Gade entèvyou sa a sou Konektem',
                        url: window.location.href
                    });
                } else {
                    alert('Pataje entèvyou sa a ak zanmi ou!');
                }
            });
        });
    }, 100);
}

// Exporter pour utilisation
export default initInterviewsPage;