//import indexPageLoader from '/JS/indexPageLoader.js'
import scriptIndx from './scriptIndx.js'
import newsFadeAnimation from './newsFadeAnimation.js'
import rpVidScript from './rpVidScript.js'
import slidesScript from './slidesScript.js'
import eventsFadeAnimation from './eventsFadeAnimation.js'
//import searchPg from './searchPg.js'
import mediaStat from './mediaStat.js'

//indexPageLoader();
slidesScript();
scriptIndx();
newsFadeAnimation();
eventsFadeAnimation();
rpVidScript();
mediaStat();
//searchPg();